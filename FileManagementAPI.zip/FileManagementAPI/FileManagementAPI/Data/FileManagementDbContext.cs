﻿
using Microsoft.EntityFrameworkCore;
using FileManagementApi.Models;

namespace FileManagementApi.Data
{
    public class FileManagementDbContext : DbContext
    {
        public FileManagementDbContext(
            DbContextOptions<FileManagementDbContext> options)
            : base(options)
        {
        }

        public DbSet<UserModel> Users { get; set; }
        public DbSet<FolderModel> Folders { get; set; }
        public DbSet<FileModel> Files { get; set; }
        public DbSet<ActivityLogModel> ActivityLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // USERS
            modelBuilder.Entity<UserModel>(entity =>
            {
                entity.HasKey(u => u.UserId);

                entity.Property(u => u.FullName)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.Property(u => u.Email)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.HasIndex(u => u.Email)
                    .IsUnique();

                entity.Property(u => u.PasswordHash)
                    .IsRequired();
            });

            // FOLDERS
            modelBuilder.Entity<FolderModel>(entity =>
            {
                entity.HasKey(f => f.FolderId);

                entity.Property(f => f.FolderName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.HasOne<FolderModel>()
                    .WithMany()
                    .HasForeignKey(f => f.ParentFolderId)
                    .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(f => f.CreatedBy)
                    .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(f => f.UpdatedBy)
                    .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(f => f.DeletedBy)
                    .OnDelete(DeleteBehavior.NoAction);
            });

            // FILES
            modelBuilder.Entity<FileModel>(entity =>
            {
                entity.HasKey(f => f.FileId);

                entity.Property(f => f.FileName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(f => f.FileType)
                    .IsRequired()
                    .HasMaxLength(20);

                entity.Property(f => f.StorageName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.HasOne<FolderModel>()
                    .WithMany()
                    .HasForeignKey(f => f.FolderId)
                    .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(f => f.CreatedBy)
                    .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(f => f.UpdatedBy)
                    .OnDelete(DeleteBehavior.NoAction);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(f => f.DeletedBy)
                    .OnDelete(DeleteBehavior.NoAction);
            });

            // ACTIVITY LOGS
            modelBuilder.Entity<ActivityLogModel>(entity =>
            {
                entity.HasKey(a => a.ActivityId);

                entity.Property(a => a.Action)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(a => a.ItemType)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(a => a.ItemName)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.HasOne<UserModel>()
                    .WithMany()
                    .HasForeignKey(a => a.UserId)
                    .OnDelete(DeleteBehavior.NoAction);
            });
        }
    }
}
