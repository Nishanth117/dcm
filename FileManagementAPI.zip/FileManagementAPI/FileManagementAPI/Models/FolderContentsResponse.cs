﻿
using System.Collections.Generic;

namespace FileManagementApi.Models
{
    public class FolderContentsResponse
    {
        public FolderModel Folder { get; set; } = new();
        public List<FolderModel> Subfolders { get; set; } = new();
        public List<FileModel> Files { get; set; } = new();
    }
}
