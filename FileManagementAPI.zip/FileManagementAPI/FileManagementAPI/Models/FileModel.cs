﻿namespace FileManagementApi.Models
{
    public class FileModel
    {
        public Guid FileId { get; set; } = Guid.NewGuid();

        public string FileName { get; set; } = string.Empty;

        public string FileType { get; set; } = string.Empty;

        public Guid FolderId { get; set; }

        public string StorageName { get; set; } = string.Empty;

        public long FileSize { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public Guid? CreatedBy { get; set; }

        public DateTime? UpdatedAt { get; set; }

        public Guid? UpdatedBy { get; set; }

        public DateTime? DeletedAt { get; set; }

        public Guid? DeletedBy { get; set; }
    }
}