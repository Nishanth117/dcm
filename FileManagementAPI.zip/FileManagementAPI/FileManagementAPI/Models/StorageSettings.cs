﻿
namespace FileManagementApi.Models
{
    public class StorageSettings
    {
        public string RootPath { get; set; } = "FileStorage";

        public int MaxFileSizeMB { get; set; } = 50;
    }
}
