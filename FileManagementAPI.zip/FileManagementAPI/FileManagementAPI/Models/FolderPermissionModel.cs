﻿
namespace FileManagementApi.Models
{
    public class FolderPermissionModel
    {
        public Guid PermissionId { get; set; } = Guid.NewGuid();

        public Guid FolderId { get; set; }

        public Guid UserId { get; set; }

        public bool CanView { get; set; } = true;

        public bool CanDownload { get; set; } = true;

        public bool CanUpload { get; set; } = false;

        public bool CanEdit { get; set; } = false;

        public bool CanDelete { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
