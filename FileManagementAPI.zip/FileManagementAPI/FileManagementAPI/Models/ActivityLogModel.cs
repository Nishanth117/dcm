﻿namespace FileManagementApi.Models
{
    public class ActivityLogModel
    {
        public Guid ActivityId { get; set; } = Guid.NewGuid();

        public Guid? UserId { get; set; }

        public string Action { get; set; } = string.Empty;

        public string ItemType { get; set; } = string.Empty;

        public Guid ItemId { get; set; }

        public string ItemName { get; set; } = string.Empty;

        public DateTime ActivityDate { get; set; } = DateTime.UtcNow;
    }
}