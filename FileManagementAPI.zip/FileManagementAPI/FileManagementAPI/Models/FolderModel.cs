﻿namespace FileManagementApi.Models
{
    public class FolderModel
    {
        public Guid FolderId { get; set; } = Guid.NewGuid();

        public string FolderName { get; set; } = string.Empty;

        public Guid? ParentFolderId { get; set; }

        // Creation details
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public Guid? CreatedBy { get; set; }

        // Update details
        public DateTime? UpdatedAt { get; set; }
        public Guid? UpdatedBy { get; set; }

        // Deletion details
        public DateTime? DeletedAt { get; set; }
        public Guid? DeletedBy { get; set; }
    }
}