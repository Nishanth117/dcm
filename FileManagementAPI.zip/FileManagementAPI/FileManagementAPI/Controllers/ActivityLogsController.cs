﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using FileManagementApi.Data;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class ActivityLogsController : ControllerBase
    {
        private readonly FileManagementDbContext _context;

        public ActivityLogsController(
            FileManagementDbContext context)
        {
            _context = context;
        }

        // GET ALL ACTIVITY LOGS

        [HttpGet]
        public async Task<IActionResult> GetAllActivityLogs(
            [FromQuery] string? searchTerm,
            [FromQuery] string? action,
            [FromQuery] string? itemType,
            [FromQuery] int page = 1,
            [FromQuery] int pageSize = 20)
        {
            if (page < 1)
                page = 1;

            if (pageSize < 1)
                pageSize = 20;

            if (pageSize > 100)
                pageSize = 100;

            var query = _context.ActivityLogs.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                query = query.Where(a =>
                    a.ItemName.Contains(searchTerm));
            }

            if (!string.IsNullOrWhiteSpace(action))
            {
                query = query.Where(a =>
                    a.Action == action);
            }

            if (!string.IsNullOrWhiteSpace(itemType))
            {
                query = query.Where(a =>
                    a.ItemType == itemType);
            }

            var totalRecords = await query.CountAsync();

            var logs = await query
                .OrderByDescending(a => a.ActivityDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(a => new
                {
                    a.ActivityId,
                    a.UserId,
                    a.Action,
                    a.ItemType,
                    a.ItemId,
                    a.ItemName,
                    a.ActivityDate
                })
                .ToListAsync();

            return Ok(new
            {
                totalRecords,
                page,
                pageSize,
                totalPages = (int)Math.Ceiling(
                    totalRecords / (double)pageSize),
                logs
            });
        }

    }
}
