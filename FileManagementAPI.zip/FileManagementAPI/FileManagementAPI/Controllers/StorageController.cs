﻿
using Microsoft.AspNetCore.Mvc;
using FileManagementApi.Services;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StorageController : ControllerBase
    {
        private readonly StorageService _storage;

        public StorageController(StorageService storage)
        {
            _storage = storage;
        }

        [HttpGet("status")]
        public IActionResult GetStatus()
        {
            return Ok(new
            {
                message = "File storage is working!",
                storagePath = _storage.RootPath,
                contentPath = _storage.ContentPath,
                foldersFile = _storage.FoldersMetadataPath,
                filesFile = _storage.FilesMetadataPath,
                storageExists = Directory.Exists(_storage.RootPath)
            });
        }
    }
}
