﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using FileManagementApi.Data;
using FileManagementApi.Models;
using FileManagementApi.Services;
using System.Security.Claims;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class PermissionsController : ControllerBase
    {
        private readonly FileManagementDbContext _context;
        private readonly ActivityLogService _activityLogService;

        public PermissionsController(
            FileManagementDbContext context,
            ActivityLogService activityLogService)
        {
            _context = context;
            _activityLogService = activityLogService;
        }

        private Guid GetCurrentUserId()
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? User.FindFirstValue("sub");

            if (!Guid.TryParse(userId, out var id))
            {
                throw new UnauthorizedAccessException(
                    "Invalid user identity.");
            }

            return id;
        }

        // ASSIGN OR UPDATE FOLDER PERMISSION
        [HttpPost("folder")]
        public async Task<IActionResult> SetFolderPermission(
            [FromBody] FolderPermissionRequest request)
        {
            var folder = await _context.Folders
                .FirstOrDefaultAsync(f =>
                    f.FolderId == request.FolderId &&
                    f.DeletedAt == null);

            if (folder == null)
            {
                return NotFound(new { message = "Folder not found." });
            }

            var userExists = await _context.Users
                .AnyAsync(u => u.UserId == request.UserId);

            if (!userExists)
            {
                return NotFound(new { message = "User not found." });
            }

            var permission = await _context.FolderPermissions
                .FirstOrDefaultAsync(p =>
                    p.FolderId == request.FolderId &&
                    p.UserId == request.UserId);

            string action;

            if (permission == null)
            {
                permission = new FolderPermissionModel
                {
                    FolderId = request.FolderId,
                    UserId = request.UserId
                };

                _context.FolderPermissions.Add(permission);
                action = "Assign Permission";
            }
            else
            {
                action = "Update Permission";
            }

            permission.CanView = request.CanView;
            permission.CanDownload = request.CanDownload;
            permission.CanUpload = request.CanUpload;
            permission.CanEdit = request.CanEdit;
            permission.CanDelete = request.CanDelete;

            await _context.SaveChangesAsync();

            // Log permission assignment or update
            await _activityLogService.LogActivityAsync(
                GetCurrentUserId(),
                action,
                "Folder Permission",
                folder.FolderId,
                folder.FolderName
            );

            return Ok(new
            {
                message = "Folder permissions saved successfully.",
                permission
            });
        }

        // GET FOLDER PERMISSIONS
        [HttpGet("folder/{folderId:guid}")]
        public async Task<IActionResult> GetFolderPermissions(Guid folderId)
        {
            var folderExists = await _context.Folders
                .AnyAsync(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null);

            if (!folderExists)
            {
                return NotFound(new { message = "Folder not found." });
            }

            var permissions = await _context.FolderPermissions
                .Where(p => p.FolderId == folderId)
                .Join(
                    _context.Users,
                    permission => permission.UserId,
                    user => user.UserId,
                    (permission, user) => new
                    {
                        permission.PermissionId,
                        permission.FolderId,
                        permission.UserId,
                        user.FullName,
                        user.Email,
                        user.Role,
                        permission.CanView,
                        permission.CanDownload,
                        permission.CanUpload,
                        permission.CanEdit,
                        permission.CanDelete,
                        permission.CreatedAt
                    })
                .ToListAsync();

            return Ok(permissions);
        }

        // REMOVE FOLDER PERMISSION
        [HttpDelete("folder/{folderId:guid}/user/{userId:guid}")]
        public async Task<IActionResult> RemoveFolderPermission(
            Guid folderId,
            Guid userId)
        {
            var permission = await _context.FolderPermissions
                .FirstOrDefaultAsync(p =>
                    p.FolderId == folderId &&
                    p.UserId == userId);

            if (permission == null)
            {
                return NotFound(new
                {
                    message = "Folder permission not found."
                });
            }

            var folder = await _context.Folders
                .FirstOrDefaultAsync(f => f.FolderId == folderId);

            if (folder == null)
            {
                return NotFound(new { message = "Folder not found." });
            }

            _context.FolderPermissions.Remove(permission);

            await _context.SaveChangesAsync();

            // Log permission removal
            await _activityLogService.LogActivityAsync(
                GetCurrentUserId(),
                "Remove Permission",
                "Folder Permission",
                folder.FolderId,
                folder.FolderName
            );

            return Ok(new
            {
                message = "Folder permission removed successfully."
            });
        }
    }

    public class FolderPermissionRequest
    {
        public Guid FolderId { get; set; }
        public Guid UserId { get; set; }
        public bool CanView { get; set; }
        public bool CanDownload { get; set; }
        public bool CanUpload { get; set; }
        public bool CanEdit { get; set; }
        public bool CanDelete { get; set; }
    }
}
