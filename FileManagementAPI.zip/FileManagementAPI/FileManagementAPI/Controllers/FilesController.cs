﻿
using Microsoft.AspNetCore.Mvc;
using FileManagementApi.Models;
using FileManagementApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Linq;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]

    public class FilesController : ControllerBase
    {
        private readonly FileService _fileService;
        private readonly PermissionService _permissionService;
        private readonly ActivityLogService _activityLogService;

        public FilesController(
    FileService fileService,
    PermissionService permissionService,
    ActivityLogService activityLogService)
        {
            _fileService = fileService;
            _permissionService = permissionService;
            _activityLogService = activityLogService;
        }
        private Guid GetCurrentUserId()
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? User.FindFirstValue("sub");

            if (!Guid.TryParse(userId, out var id))
            {
                throw new UnauthorizedAccessException(
                    "Invalid user identity.");
            }

            return id;
        }

        // Get all files
        [HttpGet]
        public async Task<IActionResult> GetFiles()
        {
            var files = _fileService.GetAllFiles();

            var userId = GetCurrentUserId();
            var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

            var visibleFiles = new List<FileModel>();

            foreach (var file in files)
            {
                bool allowed = await _permissionService.HasPermissionAsync(
                    userId,
                    role,
                    file.FolderId,
                    "view"
                );

                if (allowed)
                {
                    visibleFiles.Add(file);
                }
            }

            return Ok(visibleFiles);
        }

        // Get files inside a selected folder
        [HttpGet("folder/{folderId:guid}")]
        public async Task<IActionResult> GetFilesByFolder(Guid folderId)
        {
            var userId = GetCurrentUserId();
            var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

            bool allowed = await _permissionService.HasPermissionAsync(
                userId,
                role,
                folderId,
                "view"
            );

            if (!allowed)
            {
                return Forbid();
            }

            var files = _fileService.GetFilesByFolder(folderId);

            return Ok(files);
        }
        //Rename

        [HttpPut("{fileId:guid}/rename")]
        public async Task<IActionResult> RenameFile(
    Guid fileId,
    [FromBody] RenameFileRequest request)
        {
            try
            {
                // Find the file
                var file = _fileService.GetAllFiles()
                    .FirstOrDefault(f => f.FileId == fileId);

                if (file == null)
                {
                    return NotFound(new { message = "File not found." });
                }

                var userId = GetCurrentUserId();
                var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

                // Check edit permission
                bool allowed = await _permissionService.HasPermissionAsync(
                    userId,
                    role,
                    file.FolderId,
                    "edit"
                );

                if (!allowed)
                {
                    return Forbid();
                }

                // Rename the file
                var renamedFile = _fileService.RenameFile(
    fileId,
    request.NewFileName,
    userId
);

                // Log rename activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Rename",
                    "File",
                    renamedFile.FileId,
                    renamedFile.FileName
                );

                return Ok(new
                {
                    message = "File renamed successfully.",
                    file = renamedFile
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }
        // Create blank or content-based file
        [HttpPost("create")]
        public async Task<IActionResult> CreateFile(
            [FromBody] CreateFileRequest request)
        {
            var userId = GetCurrentUserId();
            var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

            // Check upload permission for the target folder
            bool allowed = await _permissionService.HasPermissionAsync(
                userId,
                role,
                request.FolderId,
                "upload"
            );

            if (!allowed)
            {
                return Forbid();
            }

            try
            {
                // Create the file
                var file = _fileService.CreateFile(
    request.FileName,
    request.FileType,
    request.FolderId,
    request.Content,
    userId
);

                // Log file creation activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Create",
                    "File",
                    file.FileId,
                    file.FileName
                );

                return Created(
                    $"api/files/{file.FileId}",
                    file
                );
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }

        // DOWNLOAD FILE
        [HttpGet("{fileId:guid}/download")]
        public async Task<IActionResult> DownloadFile(Guid fileId)
        {
            try
            {
                // Find the file first
                var file = _fileService.GetAllFiles()
                    .FirstOrDefault(f => f.FileId == fileId);

                if (file == null)
                {
                    return NotFound(new { message = "File not found." });
                }

                var userId = GetCurrentUserId();
                var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

                // Check download permission before accessing the physical file
                bool allowed = await _permissionService.HasPermissionAsync(
                    userId,
                    role,
                    file.FolderId,
                    "download"
                );

                if (!allowed)
                {
                    return Forbid();
                }

                // Get the physical file
                var result = _fileService.GetFileForDownload(fileId);

                // Security headers
                Response.Headers["X-Content-Type-Options"] = "nosniff";
                Response.Headers["Cache-Control"] = "no-store";

                // Log download activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Download",
                    "File",
                    file.FileId,
                    file.FileName
                );

                // Force download instead of displaying the file inline
                return PhysicalFile(
                    result.FilePath,
                    result.ContentType,
                    Path.GetFileName(result.FileName)
                );
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // UPLOAD FILE
        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadFile(
            [FromForm] Guid folderId,
            IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest(new { message = "Please select a file." });
            }
            // Maximum file size: 10 MB
            const long maxFileSize = 10 * 1024 * 1024;

            if (file.Length > maxFileSize)
            {
                return BadRequest(new
                {
                    message = "File size cannot exceed 10 MB."
                });
            }
            // Allowed file extensions
            var allowedExtensions = new[]
            {
    ".pdf",
    ".txt",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".pptx",
    ".jpg",
    ".jpeg",
    ".png"
};
            // Validate uploaded file name
            var fileName = Path.GetFileName(file.FileName);

            if (string.IsNullOrWhiteSpace(fileName) ||
                fileName != file.FileName ||
                fileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
            {
                return BadRequest(new
                {
                    message = "Invalid file name."
                });
            }

            // Get uploaded file extension
            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();

            // Validate extension
            if (!allowedExtensions.Contains(extension))
            {
                return BadRequest(new
                {
                    message = "This file type is not allowed."
                });
            }
            var userId = GetCurrentUserId();
            var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

            // Check upload permission
            bool allowed = await _permissionService.HasPermissionAsync(
                userId,
                role,
                folderId,
                "upload"
            );

            if (!allowed)
            {
                return Forbid();
            }

            try
            {
                // Upload the file
                var uploadedFile = await _fileService.UploadFileAsync(
    file,
    folderId,
    userId
);

                // Log file upload activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Upload",
                    "File",
                    uploadedFile.FileId,
                    uploadedFile.FileName
                );

                return Ok(new
                {
                    message = "File uploaded successfully.",
                    file = uploadedFile
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }
        // DELETE FILE
        [HttpDelete("{fileId:guid}")]
        public async Task<IActionResult> DeleteFile(Guid fileId)
        {
            try
            {
                // Find the file
                var file = _fileService.GetAllFiles()
                    .FirstOrDefault(f => f.FileId == fileId);

                if (file == null)
                {
                    return NotFound(new { message = "File not found." });
                }

                var userId = GetCurrentUserId();
                var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

                // Check delete permission
                bool allowed = await _permissionService.HasPermissionAsync(
                    userId,
                    role,
                    file.FolderId,
                    "delete"
                );

                if (!allowed)
                {
                    return Forbid();
                }

                // Delete the file (soft delete)
                var deletedFile = _fileService.DeleteFile(fileId, userId);

                // Log deletion activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Delete",
                    "File",
                    deletedFile.FileId,
                    deletedFile.FileName
                );

                return Ok(new
                {
                    message = "File deleted successfully.",
                    fileId = deletedFile.FileId,
                    fileName = deletedFile.FileName,
                    deletedAt = deletedFile.DeletedAt
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // RESTORE DELETED FILE
        [HttpPost("{fileId:guid}/restore")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RestoreFile(Guid fileId)
        {
            try
            {
                var userId = GetCurrentUserId();

                // Restore file and record restoring user
                var file = _fileService.RestoreFile(fileId, userId);

                // Log restoration activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Restore",
                    "File",
                    file.FileId,
                    file.FileName
                );

                return Ok(new
                {
                    message = "File restored successfully.",
                    fileId = file.FileId,
                    fileName = file.FileName
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // SEARCH FILES
        [HttpGet("search")]
        public async Task<IActionResult> SearchFiles(
    [FromQuery] string? searchTerm,
    [FromQuery] string? fileType,
    [FromQuery] Guid? folderId)
        {
            try
            {
                var files = _fileService.SearchFiles(
                    searchTerm ?? "",
                    fileType,
                    folderId
                );

                var userId = GetCurrentUserId();
                var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

                var visibleFiles = new List<FileModel>();

                foreach (var file in files)
                {
                    bool allowed = await _permissionService.HasPermissionAsync(
                        userId,
                        role,
                        file.FolderId,
                        "view"
                    );

                    if (allowed)
                    {
                        visibleFiles.Add(file);
                    }
                }

                return Ok(new
                {
                    message = "File search completed.",
                    totalResults = visibleFiles.Count,
                    files = visibleFiles
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("recycle-bin")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetDeletedFiles()
        {
            var files = _fileService.GetDeletedFiles();

            return Ok(files);
        }


        // PERMANENTLY DELETE FILE
        [HttpDelete("{fileId:guid}/permanent")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PermanentlyDeleteFile(Guid fileId)
        {
            try
            {
                // Get logged-in user ID
                var userId = GetCurrentUserId();

                // Find the file in the recycle bin
                var file = _fileService.GetDeletedFiles()
                    .FirstOrDefault(f => f.FileId == fileId);

                if (file == null)
                {
                    return NotFound(new
                    {
                        message = "Deleted file not found."
                    });
                }

                // Permanently delete the file
                var deletedFile = _fileService.PermanentlyDeleteFile(fileId);

                // Log permanent deletion activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Permanent Delete",
                    "File",
                    deletedFile.FileId,
                    deletedFile.FileName
                );

                return Ok(new
                {
                    message = "File permanently deleted.",
                    fileId = deletedFile.FileId,
                    fileName = deletedFile.FileName
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        [HttpGet("admin-test")]
        [Authorize(Roles = "Admin")]
        public IActionResult AdminTest()
        {
            return Ok("Admin access granted!");
        }

    }


    public class CreateFileRequest
    {
        public string FileName { get; set; } = string.Empty;

        public string FileType { get; set; } = string.Empty;

        public Guid FolderId { get; set; }

        public string? Content { get; set; }
    }
    public class RenameFileRequest
    {
        public string NewFileName { get; set; } = string.Empty;
    }
}
