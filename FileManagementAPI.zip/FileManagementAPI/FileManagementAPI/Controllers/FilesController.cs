﻿
using Microsoft.AspNetCore.Mvc;
using FileManagementApi.Models;
using FileManagementApi.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]

    public class FilesController : ControllerBase
    {
        private readonly FileService _fileService;

        public FilesController(FileService fileService)
        {
            _fileService = fileService;
        }

        // Get all files
        [HttpGet]
        public IActionResult GetAllFiles()
        {
            return Ok(_fileService.GetAllFiles());
        }

        // Get files inside a selected folder
        [HttpGet("folder/{folderId:guid}")]
        public IActionResult GetFilesByFolder(Guid folderId)
        {
            return Ok(_fileService.GetFilesByFolder(folderId));
        }
        [HttpPut("{fileId:guid}/rename")]
        public IActionResult RenameFile(
    Guid fileId,
    [FromBody] RenameFileRequest request)
        {
            try
            {
                var file = _fileService.RenameFile(
                    fileId,
                    request.NewFileName
                );

                return Ok(new
                {
                    message = "File renamed successfully.",
                    file
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }
        // Create blank or content-based file
        [HttpPost("create")]
        public IActionResult CreateFile(
            [FromBody] CreateFileRequest request)
        {
            try
            {
                var file = _fileService.CreateFile(
                    request.FileName,
                    request.FileType,
                    request.FolderId,
                    request.Content
                );

                return Created(
                    $"api/files/{file.FileId}",
                    file
                );
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }
        [HttpGet("{fileId:guid}/download")]
        public IActionResult DownloadFile(Guid fileId)
        {
            try
            {
                var result = _fileService.GetFileForDownload(fileId);

                return PhysicalFile(
                    result.FilePath,
                    result.ContentType,
                    result.FileName
                );
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        // UPLOAD FILE
        [HttpPost("upload")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadFile(
    [FromForm] Guid folderId,
    IFormFile file)
        {
            try
            {
                var uploadedFile = await _fileService.UploadFileAsync(
                    file,
                    folderId
                );

                return Ok(new
                {
                    message = "File uploaded successfully.",
                    file = uploadedFile
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }
        // DELETE FILE
        [HttpDelete("{fileId:guid}")]
        public IActionResult DeleteFile(Guid fileId)
        {
            try
            {
                var file = _fileService.DeleteFile(fileId);

                return Ok(new
                {
                    message = "File deleted successfully.",
                    fileId = file.FileId,
                    fileName = file.FileName,
                    deletedAt = file.DeletedAt
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }
        // RESTORE DELETED FILE
        [HttpPost("{fileId:guid}/restore")]
        public IActionResult RestoreFile(Guid fileId)
        {
            try
            {
                var file = _fileService.RestoreFile(fileId);

                return Ok(new
                {
                    message = "File restored successfully.",
                    fileId = file.FileId,
                    fileName = file.FileName
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }
        // SEARCH FILES
        [HttpGet("search")]
        public IActionResult SearchFiles(
            [FromQuery] string? searchTerm,
            [FromQuery] string? fileType,
            [FromQuery] Guid? folderId)
        {
            try
            {
                var files = _fileService.SearchFiles(
                    searchTerm ?? "",
                    fileType,
                    folderId
                );

                return Ok(new
                {
                    message = "File search completed.",
                    totalResults = files.Count,
                    files
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("recycle-bin")]
        public IActionResult GetDeletedFiles()
        {
            var files = _fileService.GetDeletedFiles();
            return Ok(files);
        }

        [HttpDelete("{fileId:guid}/permanent")]
        public IActionResult PermanentlyDeleteFile(Guid fileId)
        {
            try
            {
                _fileService.PermanentlyDeleteFile(fileId);
                return Ok(new { message = "File permanently deleted." });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }


    }

    public class CreateFileRequest
    {
        public string FileName { get; set; } = string.Empty;

        public string FileType { get; set; } = string.Empty;

        public Guid FolderId { get; set; }

        public string? Content { get; set; }
    }
    public class RenameFileRequest
    {
        public string NewFileName { get; set; } = string.Empty;
    }
}
