﻿
using Microsoft.AspNetCore.Mvc;
using FileManagementApi.Models;
using FileManagementApi.Services;
using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]

    public class FoldersController : ControllerBase
    {
        private readonly FolderService _folderService;

        public FoldersController(FolderService folderService)
        {
            _folderService = folderService;
        }

        [HttpGet]
        public IActionResult GetFolders()
        {
            return Ok(_folderService.GetAllFolders());
        }

        [HttpPost]
        public IActionResult CreateFolder(
            [FromBody] CreateFolderRequest request)
        {
            try
            {
                var folder = _folderService.CreateFolder(
                    request.FolderName,
                    request.ParentFolderId
                );

                return Created(
                    $"api/folders/{folder.FolderId}",
                    folder
                );
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }

        [HttpPut("{id:guid}/rename")]
        public IActionResult RenameFolder(
            Guid id,
            [FromBody] RenameFolderRequest request)
        {
            try
            {
                var folder = _folderService.RenameFolder(
                    id,
                    request.NewName
                );

                return Ok(folder);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }
        // DELETE FOLDER
        [HttpDelete("{id:guid}")]
        public IActionResult DeleteFolder(Guid id)
        {
            try
            {
                var folder = _folderService.DeleteFolder(id);

                return Ok(new
                {
                    message = "Folder and its contents deleted successfully.",
                    folderId = folder.FolderId,
                    folderName = folder.FolderName,
                    deletedAt = folder.DeletedAt
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }
        // RESTORE DELETED FOLDER
        [HttpPost("{id:guid}/restore")]
        public IActionResult RestoreFolder(Guid id)
        {
            try
            {
                var folder = _folderService.RestoreFolder(id);

                return Ok(new
                {
                    message = "Folder and its contents restored successfully.",
                    folderId = folder.FolderId,
                    folderName = folder.FolderName
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }
        // SEARCH FOLDERS
        [HttpGet("search")]
        public IActionResult SearchFolders([FromQuery] string searchTerm)
        {
            try
            {
                var folders = _folderService.SearchFolders(searchTerm);

                return Ok(new
                {
                    message = "Folder search completed.",
                    totalResults = folders.Count,
                    folders
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("{id:guid}/contents")]
        public IActionResult GetFolderContents(Guid id)
        {
            try
            {
                var result = _folderService.GetFolderContents(id);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        [HttpGet("recycle-bin")]
        public IActionResult GetDeletedFolders()
        {
            var folders = _folderService.GetDeletedFolders();
            return Ok(folders);
        }

        [HttpDelete("{id:guid}/permanent")]
        public IActionResult PermanentlyDeleteFolder(Guid id)
        {
            try
            {
                _folderService.PermanentlyDeleteFolder(id);
                return Ok(new { message = "Folder and its contents permanently deleted." });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }


    }

    public class CreateFolderRequest
    {
        public string FolderName { get; set; } = string.Empty;

        public Guid? ParentFolderId { get; set; }
    }

    public class RenameFolderRequest
    {
        public string NewName { get; set; } = string.Empty;
    }
}
