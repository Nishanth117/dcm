﻿
using DocumentFormat.OpenXml.Spreadsheet;
using FileManagementApi.Models;
using FileManagementApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace FileManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class FoldersController : ControllerBase
    {
        private readonly FolderService _folderService;
        private readonly PermissionService _permissionService;
        private readonly ActivityLogService _activityLogService;

        public FoldersController(
            FolderService folderService,
            PermissionService permissionService,
            ActivityLogService activityLogService)
        {
            _folderService = folderService;
            _permissionService = permissionService;
            _activityLogService = activityLogService;
        }

        private Guid GetCurrentUserId()
        {
            var userId =
                User.FindFirstValue(ClaimTypes.NameIdentifier)
                ?? User.FindFirstValue("sub");

            if (!Guid.TryParse(userId, out var id))
            {
                throw new UnauthorizedAccessException(
                    "Invalid user identity.");
            }

            return id;
        }

        // GET ALL FOLDERS
        [HttpGet]
        public async Task<IActionResult> GetFolders()
        {
            var folders = _folderService.GetAllFolders();
            var userId = GetCurrentUserId();

            var visibleFolders = new List<FolderModel>();

            foreach (var folder in folders)
            {
                bool allowed = await _permissionService.HasPermissionAsync(
                    userId,
                    User.IsInRole("Admin") ? "Admin" : "Viewer",
                    folder.FolderId,
                    "view"
                );

                if (allowed)
                {
                    visibleFolders.Add(folder);
                }
            }

            return Ok(visibleFolders);
        }

        // CREATE FOLDER
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> CreateFolder(
            [FromBody] CreateFolderRequest request)
        {
            try
            {
                var userId = GetCurrentUserId();
                var folder = _folderService.CreateFolder(
    request.FolderName,
    request.ParentFolderId,
    userId
);

                // Log folder creation activity
                await _activityLogService.LogActivityAsync(
                    GetCurrentUserId(),
                    "Create",
                    "Folder",
                    folder.FolderId,
                    folder.FolderName
                );

                return Created(
                    $"api/folders/{folder.FolderId}",
                    folder
                );
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }

        // RENAME FOLDER
        [HttpPut("{id:guid}/rename")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RenameFolder(
            Guid id,
            [FromBody] RenameFolderRequest request)
        {
            try
            {
                // Rename the folder
                var userId = GetCurrentUserId();

                var folder = _folderService.RenameFolder(
                    id,
                    request.NewName,
                    userId
                );

                // Log folder rename activity
                await _activityLogService.LogActivityAsync(
    userId,
    "Rename",
    "Folder",
    folder.FolderId,
    folder.FolderName
);

                return Ok(folder);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }

        // DELETE FOLDER
        [HttpDelete("{id:guid}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteFolder(Guid id)
        {
            try
            {
                var userId = GetCurrentUserId();

                // Soft delete the folder
                var folder = _folderService.DeleteFolder(id, userId);

                // Log folder deletion activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Delete",
                    "Folder",
                    folder.FolderId,
                    folder.FolderName
                );

                return Ok(new
                {
                    message = "Folder and its contents deleted successfully.",
                    folderId = folder.FolderId,
                    folderName = folder.FolderName,
                    deletedAt = folder.DeletedAt
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }


        // RESTORE DELETED FOLDER
        [HttpPost("{id:guid}/restore")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> RestoreFolder(Guid id)
        {
            try
            {
                // Get logged-in user ID
                var userId = GetCurrentUserId();

                // Restore the folder and its contents
                var folder = _folderService.RestoreFolder(id, userId);

                // Log folder restoration activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Restore",
                    "Folder",
                    folder.FolderId,
                    folder.FolderName
                );

                return Ok(new
                {
                    message = "Folder and its contents restored successfully.",
                    folderId = folder.FolderId,
                    folderName = folder.FolderName
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
            catch (FileNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }


        // SEARCH FOLDERS
        [HttpGet("search")]
        public async Task<IActionResult> SearchFolders(
            [FromQuery] string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return BadRequest(new { message = "Search term is required." });
            }

            var folders = _folderService.SearchFolders(searchTerm);
            var userId = GetCurrentUserId();
            var role = User.FindFirstValue(ClaimTypes.Role) ?? "Viewer";

            var visibleFolders = new List<FolderModel>();

            foreach (var folder in folders)
            {
                bool allowed = await _permissionService.HasPermissionAsync(
                    userId,
                    role,
                    folder.FolderId,
                    "view"
                );

                if (allowed)
                {
                    visibleFolders.Add(folder);
                }
            }

            return Ok(visibleFolders);
        }

        // GET FOLDER CONTENTS
        [HttpGet("{id:guid}/contents")]
        public async Task<IActionResult> GetFolderContents(Guid id)
        {
            var allowed = await _permissionService.HasPermissionAsync(
                GetCurrentUserId(),
                User.IsInRole("Admin") ? "Admin" : "Viewer",
                id,
                "view"
            );

            if (!allowed)
            {
                return Forbid();
            }

            try
            {
                var result = _folderService.GetFolderContents(id);
                return Ok(result);
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // GET DELETED FOLDERS
        [HttpGet("recycle-bin")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetDeletedFolders()
        {
            var folders = _folderService.GetDeletedFolders();
            return Ok(folders);
        }


        // PERMANENTLY DELETE FOLDER
        [HttpDelete("{id:guid}/permanent")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> PermanentlyDeleteFolder(Guid id)
        {
            try
            {
                // Get logged-in user ID
                var userId = GetCurrentUserId();

                // Get folder details before permanent deletion
                var folder = _folderService.GetDeletedFolders()
                    .FirstOrDefault(f => f.FolderId == id);

                if (folder == null)
                {
                    return NotFound(new
                    {
                        message = "Deleted folder not found."
                    });
                }

                // Permanently delete the folder and its contents
                var deletedFolder = _folderService.PermanentlyDeleteFolder(id);

                // Log permanent deletion activity
                await _activityLogService.LogActivityAsync(
                    userId,
                    "Permanent Delete",
                    "Folder",
                    deletedFolder.FolderId,
                    deletedFolder.FolderName
                );

                return Ok(new
                {
                    message = "Folder and its contents permanently deleted.",
                    folderId = deletedFolder.FolderId,
                    folderName = deletedFolder.FolderName
                });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { message = ex.Message });
            }
        }

    }

    public class CreateFolderRequest
    {
        public string FolderName { get; set; } = string.Empty;
        public Guid? ParentFolderId { get; set; }
    }

    public class RenameFolderRequest
    {
        public string NewName { get; set; } = string.Empty;
    }
}
