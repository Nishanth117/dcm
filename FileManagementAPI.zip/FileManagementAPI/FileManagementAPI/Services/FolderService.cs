﻿
using FileManagementApi.Data;
using FileManagementApi.Models;
using Microsoft.EntityFrameworkCore;
using System.IO;
using System.Collections.Generic;
using System;
using System.Linq;

namespace FileManagementApi.Services
{
    public class FolderService
    {
        private readonly FileManagementDbContext _context;
        private readonly StorageService _storage;

        public FolderService(
            FileManagementDbContext context,
            StorageService storage)
        {
            _context = context;
            _storage = storage;
        }

        // GET ALL FOLDERS
        public List<FolderModel> GetAllFolders()
        {
            return _context.Folders
                .AsNoTracking()
                .Where(f => f.DeletedAt == null)
                .OrderBy(f => f.CreatedAt)
                .ToList();
        }

        public List<FolderModel> GetDeletedFolders()
        {
            return _context.Folders
                .AsNoTracking()
                .Where(f => f.DeletedAt != null)
                .OrderByDescending(f => f.DeletedAt)
                .ToList();
        }


        // CREATE FOLDER
        public FolderModel CreateFolder(
            string folderName,
            Guid? parentFolderId)
        {
            if (string.IsNullOrWhiteSpace(folderName))
                throw new ArgumentException(
                    "Folder name is required.");

            folderName = folderName.Trim();

            // Check parent folder
            if (parentFolderId.HasValue)
            {
                var parentExists = _context.Folders.Any(f =>
                    f.FolderId == parentFolderId.Value &&
                    f.DeletedAt == null);

                if (!parentExists)
                    throw new KeyNotFoundException(
                        "Parent folder not found.");
            }

            // Check duplicate folder name
            bool duplicateExists = _context.Folders.Any(f =>
                f.ParentFolderId == parentFolderId &&
                f.DeletedAt == null &&
                f.FolderName == folderName);

            if (duplicateExists)
                throw new InvalidOperationException(
                    "A folder with this name already exists.");

            var folder = new FolderModel
            {
                FolderName = folderName,
                ParentFolderId = parentFolderId,
                CreatedAt = DateTime.UtcNow
            };

            // Create physical folder first
            string folderPath = Path.Combine(
                _storage.ContentPath,
                folder.FolderId.ToString()
            );

            Directory.CreateDirectory(folderPath);

            try
            {
                // Save metadata in SQL Server
                _context.Folders.Add(folder);
                _context.SaveChanges();

                return folder;
            }
            catch
            {
                // Clean up physical directory if database save fails
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);

                throw;
            }
        }

        // RENAME FOLDER
        public FolderModel RenameFolder(
            Guid folderId,
            string newName)
        {
            if (string.IsNullOrWhiteSpace(newName))
                throw new ArgumentException(
                    "New folder name is required.");

            newName = newName.Trim();

            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException(
                    "Folder not found.");

            // Check duplicate name in the same parent folder
            bool duplicateExists = _context.Folders.Any(f =>
                f.FolderId != folderId &&
                f.ParentFolderId == folder.ParentFolderId &&
                f.DeletedAt == null &&
                f.FolderName == newName);

            if (duplicateExists)
                throw new InvalidOperationException(
                    "A folder with this name already exists.");

            folder.FolderName = newName;
            folder.UpdatedAt = DateTime.UtcNow;

            _context.SaveChanges();

            return folder;
        }
        // DELETE FOLDER AND ALL ITS CONTENTS
        public FolderModel DeleteFolder(Guid folderId)
        {
            // Find the requested active folder
            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException("Folder not found.");

            // Get all active folders
            var allFolders = _context.Folders
                .Where(f => f.DeletedAt == null)
                .ToList();

            // Find the selected folder and all descendants
            var folderIds = new HashSet<Guid> { folderId };

            bool added;

            do
            {
                added = false;

                foreach (var child in allFolders)
                {
                    if (child.ParentFolderId.HasValue &&
                        folderIds.Contains(child.ParentFolderId.Value) &&
                        folderIds.Add(child.FolderId))
                    {
                        added = true;
                    }
                }

            } while (added);

            // Find all active files inside these folders
            var files = _context.Files
                .Where(f =>
                    folderIds.Contains(f.FolderId) &&
                    f.DeletedAt == null)
                .ToList();

            DateTime deletedTime = DateTime.UtcNow;

            // Soft-delete all folders
            foreach (var item in allFolders.Where(f =>
                folderIds.Contains(f.FolderId)))
            {
                item.DeletedAt = deletedTime;
                item.DeletedBy = null;
            }

            // Soft-delete all files
            foreach (var file in files)
            {
                file.DeletedAt = deletedTime;
                file.DeletedBy = null;
            }

            // Save all changes together
            using var transaction = _context.Database.BeginTransaction();

            try
            {
                _context.SaveChanges();
                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

            return folder;
        }

        // RESTORE DELETED FOLDER AND ITS CONTENTS
        public FolderModel RestoreFolder(Guid folderId)
        {
            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt != null);

            if (folder == null)
                throw new KeyNotFoundException("Deleted folder not found.");

            // Remember the deletion timestamp shared by this deletion operation
            DateTime deletionTime = folder.DeletedAt.Value;

            // Check that the parent folder is active
            if (folder.ParentFolderId.HasValue)
            {
                bool parentExists = _context.Folders.Any(f =>
                    f.FolderId == folder.ParentFolderId.Value &&
                    f.DeletedAt == null);

                if (!parentExists)
                    throw new InvalidOperationException(
                        "Restore the parent folder first.");
            }

            using var transaction = _context.Database.BeginTransaction();

            try
            {
                var allFolders = _context.Folders
                    .Where(f => f.DeletedAt != null)
                    .ToList();

                var allFiles = _context.Files
                    .Where(f => f.DeletedAt != null)
                    .ToList();

                // Only restore folders deleted in the same operation
                var foldersToRestore = allFolders
                    .Where(f => f.DeletedAt == deletionTime)
                    .ToList();

                var folderIds = new HashSet<Guid> { folderId };

                bool added;

                do
                {
                    added = false;

                    foreach (var child in foldersToRestore)
                    {
                        if (child.ParentFolderId.HasValue &&
                            folderIds.Contains(child.ParentFolderId.Value) &&
                            folderIds.Add(child.FolderId))
                        {
                            added = true;
                        }
                    }

                } while (added);

                // Check duplicate folder names before restoring
                foreach (var item in foldersToRestore.Where(f =>
                    folderIds.Contains(f.FolderId)))
                {
                    bool duplicate = _context.Folders.Any(f =>
                        f.FolderId != item.FolderId &&
                        f.ParentFolderId == item.ParentFolderId &&
                        f.DeletedAt == null &&
                        f.FolderName == item.FolderName);

                    if (duplicate)
                        throw new InvalidOperationException(
                            $"An active folder named '{item.FolderName}' already exists.");
                }

                // Restore only files deleted in the same operation
                var filesToRestore = allFiles
                    .Where(f =>
                        folderIds.Contains(f.FolderId) &&
                        f.DeletedAt == deletionTime)
                    .ToList();

                // Check duplicate file names and physical files
                foreach (var file in filesToRestore)
                {
                    bool duplicate = _context.Files.Any(f =>
                        f.FileId != file.FileId &&
                        f.FolderId == file.FolderId &&
                        f.DeletedAt == null &&
                        f.FileName == file.FileName);

                    if (duplicate)
                        throw new InvalidOperationException(
                            $"An active file named '{file.FileName}' already exists.");

                    string physicalPath = Path.Combine(
                        _storage.ContentPath,
                        file.FolderId.ToString(),
                        file.StorageName);

                    if (!System.IO.File.Exists(physicalPath))
                        throw new FileNotFoundException(
                            $"Original file '{file.FileName}' was not found.");
                }

                // Restore folders
                foreach (var item in foldersToRestore.Where(f =>
                    folderIds.Contains(f.FolderId)))
                {
                    item.DeletedAt = null;
                    item.DeletedBy = null;
                    item.UpdatedAt = DateTime.UtcNow;
                }

                // Restore files
                foreach (var file in filesToRestore)
                {
                    file.DeletedAt = null;
                    file.DeletedBy = null;
                    file.UpdatedAt = DateTime.UtcNow;
                }

                _context.SaveChanges();
                transaction.Commit();

                return folder;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }
        // SEARCH FOLDERS
        public List<FolderModel> SearchFolders(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                throw new ArgumentException("Search term is required.");

            searchTerm = searchTerm.Trim();

            return _context.Folders
                .AsNoTracking()
                .Where(f =>
                    f.DeletedAt == null &&
                    f.FolderName.Contains(searchTerm))
                .OrderBy(f => f.FolderName)
                .ToList();
        }

        public FolderContentsResponse GetFolderContents(Guid folderId)
        {
            var folder = _context.Folders
                .AsNoTracking()
                .FirstOrDefault(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException("Folder not found.");

            var subfolders = _context.Folders
                .AsNoTracking()
                .Where(f =>
                    f.ParentFolderId == folderId &&
                    f.DeletedAt == null)
                .OrderBy(f => f.FolderName)
                .ToList();

            var files = _context.Files
                .AsNoTracking()
                .Where(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null)
                .OrderBy(f => f.FileName)
                .ToList();

            return new FolderContentsResponse
            {
                Folder = folder,
                Subfolders = subfolders,
                Files = files
            };
        }

        public void PermanentlyDeleteFolder(Guid folderId)
        {
            var rootFolder = _context.Folders
                .FirstOrDefault(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt != null);

            if (rootFolder == null)
                throw new KeyNotFoundException(
                    "Deleted folder not found in recycle bin.");

            // Collect the root folder and all its descendants.
            var foldersToDelete = new List<FolderModel> { rootFolder };
            var folderIds = new HashSet<Guid> { folderId };

            for (int i = 0; i < foldersToDelete.Count; i++)
            {
                var parentId = foldersToDelete[i].FolderId;

                var children = _context.Folders
                    .Where(f => f.ParentFolderId == parentId)
                    .ToList();

                foreach (var child in children)
                {
                    if (folderIds.Add(child.FolderId))
                        foldersToDelete.Add(child);
                }
            }

            var ids = folderIds.ToList();

            var filesToDelete = _context.Files
                .Where(f => ids.Contains(f.FolderId))
                .ToList();

            // Save physical paths before removing database records.
            var filePaths = filesToDelete.Select(file =>
                Path.GetFullPath(Path.Combine(
                    _storage.ContentPath,
                    file.FolderId.ToString(),
                    file.StorageName
                ))).ToList();

            var folderPaths = ids.Select(id =>
                Path.GetFullPath(Path.Combine(
                    _storage.ContentPath,
                    id.ToString()
                ))).ToList();

            // Remove file records first.
            _context.Files.RemoveRange(filesToDelete);
            _context.SaveChanges();

            // Remove folders from deepest to root to respect the parent FK.
            var foldersByDepth = foldersToDelete
                .OrderByDescending(f =>
                    GetFolderDepth(f, foldersToDelete))
                .ToList();

            foreach (var folder in foldersByDepth)
            {
                _context.Folders.Remove(folder);
                _context.SaveChanges();
            }

            // Remove physical files and directories after database deletion.
            foreach (var path in filePaths)
            {
                if (System.IO.File.Exists(path))
                    System.IO.File.Delete(path);
            }

            foreach (var path in folderPaths
                .OrderByDescending(p => p.Length))
            {
                if (Directory.Exists(path))
                    Directory.Delete(path, recursive: true);
            }
        }

        private static int GetFolderDepth(
            FolderModel folder,
            List<FolderModel> allFolders)
        {
            int depth = 0;
            var parentId = folder.ParentFolderId;

            while (parentId.HasValue)
            {
                var parent = allFolders.FirstOrDefault(
                    f => f.FolderId == parentId.Value);

                if (parent == null)
                    break;

                depth++;
                parentId = parent.ParentFolderId;
            }

            return depth;
        }


    }
}
