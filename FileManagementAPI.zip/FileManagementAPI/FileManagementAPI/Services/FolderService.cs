﻿
using FileManagementApi.Data;
using FileManagementApi.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace FileManagementApi.Services
{
    public class FolderService
    {
        private readonly FileManagementDbContext _context;
        private readonly StorageService _storage;

        public FolderService(
            FileManagementDbContext context,
            StorageService storage)
        {
            _context = context;
            _storage = storage;
        }

        // GET ALL ACTIVE FOLDERS
        public List<FolderModel> GetAllFolders()
        {
            return _context.Folders
                .AsNoTracking()
                .Where(f => f.DeletedAt == null)
                .OrderBy(f => f.CreatedAt)
                .ToList();
        }

        // GET DELETED FOLDERS
        public List<FolderModel> GetDeletedFolders()
        {
            return _context.Folders
                .AsNoTracking()
                .Where(f => f.DeletedAt != null)
                .OrderByDescending(f => f.DeletedAt)
                .ToList();
        }

        // CREATE FOLDER USING ACTUAL NAME
        public FolderModel CreateFolder(
            string folderName,
            Guid? parentFolderId)
        {
            StorageService.ValidateSegment(folderName);
            folderName = folderName.Trim();

            string parentPath = _storage.ContentPath;

            // Check parent folder
            if (parentFolderId.HasValue)
            {
                var parent = _context.Folders.FirstOrDefault(f =>
                    f.FolderId == parentFolderId.Value &&
                    f.DeletedAt == null);

                if (parent == null)
                    throw new KeyNotFoundException(
                        "Parent folder not found.");

                parentPath = GetFolderPhysicalPath(
                    parent.FolderId);

                if (!Directory.Exists(parentPath))
                    throw new DirectoryNotFoundException(
                        "Parent physical folder was not found.");
            }

            // Check duplicate folder name
            bool duplicateExists = _context.Folders
                .Where(f =>
                    f.ParentFolderId == parentFolderId &&
                    f.DeletedAt == null)
                .AsEnumerable()
                .Any(f => f.FolderName.Equals(
                    folderName,
                    StringComparison.OrdinalIgnoreCase));

            if (duplicateExists)
                throw new InvalidOperationException(
                    "A folder with this name already exists.");

            var folder = new FolderModel
            {
                FolderName = folderName,
                ParentFolderId = parentFolderId,
                CreatedAt = DateTime.UtcNow
            };

            // Physical path uses the actual folder name
            string folderPath = _storage.GetContentPath(
                GetRelativeFolderSegments(parentFolderId)
                    .Concat(new[] { folderName })
                    .ToArray());

            if (Directory.Exists(folderPath))
                throw new InvalidOperationException(
                    "A physical folder with this name already exists.");

            Directory.CreateDirectory(folderPath);

            try
            {
                _context.Folders.Add(folder);
                _context.SaveChanges();

                return folder;
            }
            catch
            {
                if (Directory.Exists(folderPath))
                    Directory.Delete(folderPath, true);

                throw;
            }
        }

        // RENAME PHYSICAL FOLDER AND DATABASE NAME
        public FolderModel RenameFolder(
            Guid folderId,
            string newName)
        {
            StorageService.ValidateSegment(newName);
            newName = newName.Trim();

            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException(
                    "Folder not found.");

            bool duplicateExists = _context.Folders
                .Where(f =>
                    f.FolderId != folderId &&
                    f.ParentFolderId == folder.ParentFolderId &&
                    f.DeletedAt == null)
                .AsEnumerable()
                .Any(f => f.FolderName.Equals(
                    newName,
                    StringComparison.OrdinalIgnoreCase));

            if (duplicateExists)
                throw new InvalidOperationException(
                    "A folder with this name already exists.");

            string oldPath = GetFolderPhysicalPath(folderId);

            string newPath = _storage.GetContentPath(
                GetRelativeFolderSegments(folder.ParentFolderId)
                    .Concat(new[] { newName })
                    .ToArray());

            if (!Directory.Exists(oldPath))
                throw new DirectoryNotFoundException(
                    "Physical folder was not found.");

            if (Directory.Exists(newPath))
                throw new InvalidOperationException(
                    "A physical folder with this name already exists.");

            // Rename the physical directory
            Directory.Move(oldPath, newPath);

            try
            {
                folder.FolderName = newName;
                folder.UpdatedAt = DateTime.UtcNow;

                _context.SaveChanges();

                return folder;
            }
            catch
            {
                // Roll back physical rename if database save fails
                if (Directory.Exists(newPath) &&
                    !Directory.Exists(oldPath))
                {
                    Directory.Move(newPath, oldPath);
                }

                throw;
            }
        }

        // SOFT DELETE FOLDER AND ALL CONTENTS
        public FolderModel DeleteFolder(Guid folderId)
        {
            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException("Folder not found.");

            var allFolders = _context.Folders
                .Where(f => f.DeletedAt == null)
                .ToList();

            var folderIds = new HashSet<Guid> { folderId };

            bool added;

            do
            {
                added = false;

                foreach (var child in allFolders)
                {
                    if (child.ParentFolderId.HasValue &&
                        folderIds.Contains(child.ParentFolderId.Value) &&
                        folderIds.Add(child.FolderId))
                    {
                        added = true;
                    }
                }

            } while (added);

            var files = _context.Files
                .Where(f =>
                    folderIds.Contains(f.FolderId) &&
                    f.DeletedAt == null)
                .ToList();

            DateTime deletedTime = DateTime.UtcNow;

            foreach (var item in allFolders.Where(f =>
                folderIds.Contains(f.FolderId)))
            {
                item.DeletedAt = deletedTime;
                item.DeletedBy = null;
            }

            foreach (var file in files)
            {
                file.DeletedAt = deletedTime;
                file.DeletedBy = null;
            }

            using var transaction =
                _context.Database.BeginTransaction();

            try
            {
                _context.SaveChanges();
                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
                throw;
            }

            return folder;
        }

        // RESTORE DELETED FOLDER AND ITS CONTENTS
        public FolderModel RestoreFolder(Guid folderId)
        {
            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt != null);

            if (folder == null)
                throw new KeyNotFoundException(
                    "Deleted folder not found.");

            DateTime deletionTime = folder.DeletedAt.Value;

            // Parent must be active
            if (folder.ParentFolderId.HasValue)
            {
                bool parentExists = _context.Folders.Any(f =>
                    f.FolderId == folder.ParentFolderId.Value &&
                    f.DeletedAt == null);

                if (!parentExists)
                    throw new InvalidOperationException(
                        "Restore the parent folder first.");
            }

            using var transaction =
                _context.Database.BeginTransaction();

            try
            {
                var allFolders = _context.Folders
                    .Where(f => f.DeletedAt != null)
                    .ToList();

                var allFiles = _context.Files
                    .Where(f => f.DeletedAt != null)
                    .ToList();

                var foldersToRestore = allFolders
                    .Where(f => f.DeletedAt == deletionTime)
                    .ToList();

                var folderIds = new HashSet<Guid> { folderId };

                bool added;

                do
                {
                    added = false;

                    foreach (var child in foldersToRestore)
                    {
                        if (child.ParentFolderId.HasValue &&
                            folderIds.Contains(child.ParentFolderId.Value) &&
                            folderIds.Add(child.FolderId))
                        {
                            added = true;
                        }
                    }

                } while (added);

                // Check duplicate folders
                foreach (var item in foldersToRestore.Where(f =>
                    folderIds.Contains(f.FolderId)))
                {
                    bool duplicate = _context.Folders
                        .Where(f =>
                            f.FolderId != item.FolderId &&
                            f.ParentFolderId == item.ParentFolderId &&
                            f.DeletedAt == null)
                        .AsEnumerable()
                        .Any(f => f.FolderName.Equals(
                            item.FolderName,
                            StringComparison.OrdinalIgnoreCase));

                    if (duplicate)
                        throw new InvalidOperationException(
                            $"An active folder named '{item.FolderName}' already exists.");

                    // Physical directory should still exist
                    string folderPath =
                        GetFolderPhysicalPath(item.FolderId);

                    if (!Directory.Exists(folderPath))
                        throw new DirectoryNotFoundException(
                            $"Original folder '{item.FolderName}' was not found.");
                }

                var filesToRestore = allFiles
                    .Where(f =>
                        folderIds.Contains(f.FolderId) &&
                        f.DeletedAt == deletionTime)
                    .ToList();

                // Check duplicate files and physical files
                foreach (var file in filesToRestore)
                {
                    bool duplicate = _context.Files
                        .Where(f =>
                            f.FileId != file.FileId &&
                            f.FolderId == file.FolderId &&
                            f.DeletedAt == null)
                        .AsEnumerable()
                        .Any(f => f.FileName.Equals(
                            file.FileName,
                            StringComparison.OrdinalIgnoreCase));

                    if (duplicate)
                        throw new InvalidOperationException(
                            $"An active file named '{file.FileName}' already exists.");

                    // StorageName will contain the actual file name
                    // after we update FileService.
                    string physicalPath = Path.Combine(
                        GetFolderPhysicalPath(file.FolderId),
                        file.StorageName);

                    if (!System.IO.File.Exists(physicalPath))
                        throw new FileNotFoundException(
                            $"Original file '{file.FileName}' was not found.");
                }

                // Restore folders
                foreach (var item in foldersToRestore.Where(f =>
                    folderIds.Contains(f.FolderId)))
                {
                    item.DeletedAt = null;
                    item.DeletedBy = null;
                    item.UpdatedAt = DateTime.UtcNow;
                }

                // Restore files
                foreach (var file in filesToRestore)
                {
                    file.DeletedAt = null;
                    file.DeletedBy = null;
                    file.UpdatedAt = DateTime.UtcNow;
                }

                _context.SaveChanges();
                transaction.Commit();

                return folder;
            }
            catch
            {
                transaction.Rollback();
                throw;
            }
        }

        // SEARCH FOLDERS
        public List<FolderModel> SearchFolders(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                throw new ArgumentException(
                    "Search term is required.");

            searchTerm = searchTerm.Trim();

            return _context.Folders
                .AsNoTracking()
                .Where(f =>
                    f.DeletedAt == null &&
                    f.FolderName.Contains(searchTerm))
                .OrderBy(f => f.FolderName)
                .ToList();
        }

        // GET FOLDER CONTENTS
        public FolderContentsResponse GetFolderContents(Guid folderId)
        {
            var folder = _context.Folders
                .AsNoTracking()
                .FirstOrDefault(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException("Folder not found.");

            var subfolders = _context.Folders
                .AsNoTracking()
                .Where(f =>
                    f.ParentFolderId == folderId &&
                    f.DeletedAt == null)
                .OrderBy(f => f.FolderName)
                .ToList();

            var files = _context.Files
                .AsNoTracking()
                .Where(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null)
                .OrderBy(f => f.FileName)
                .ToList();

            return new FolderContentsResponse
            {
                Folder = folder,
                Subfolders = subfolders,
                Files = files
            };
        }

        // PERMANENTLY DELETE FOLDER AND ALL CONTENTS
        public void PermanentlyDeleteFolder(Guid folderId)
        {
            var rootFolder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt != null);

            if (rootFolder == null)
                throw new KeyNotFoundException(
                    "Deleted folder not found in recycle bin.");

            var foldersToDelete =
                new List<FolderModel> { rootFolder };

            var folderIds = new HashSet<Guid> { folderId };

            for (int i = 0; i < foldersToDelete.Count; i++)
            {
                var parentId = foldersToDelete[i].FolderId;

                var children = _context.Folders
                    .Where(f => f.ParentFolderId == parentId)
                    .ToList();

                foreach (var child in children)
                {
                    if (folderIds.Add(child.FolderId))
                        foldersToDelete.Add(child);
                }
            }

            // Ensure the entire tree is deleted
            if (foldersToDelete.Any(f => f.DeletedAt == null))
                throw new InvalidOperationException(
                    "All child folders must be deleted first.");

            var ids = folderIds.ToList();

            var filesToDelete = _context.Files
                .Where(f => ids.Contains(f.FolderId))
                .ToList();

            // Resolve paths before deleting database records
            var rootPath = GetFolderPhysicalPath(folderId);

            // Delete file records
            _context.Files.RemoveRange(filesToDelete);
            _context.SaveChanges();

            // Delete folders from deepest to root
            var foldersByDepth = foldersToDelete
                .OrderByDescending(f =>
                    GetFolderDepth(f, foldersToDelete))
                .ToList();

            foreach (var item in foldersByDepth)
            {
                _context.Folders.Remove(item);
                _context.SaveChanges();
            }

            // Delete the physical root directory and everything inside
            if (Directory.Exists(rootPath))
                Directory.Delete(rootPath, recursive: true);
        }

        // GET PHYSICAL PATH OF A FOLDER
        private string GetFolderPhysicalPath(Guid folderId)
        {
            var folders = _context.Folders
                .AsNoTracking()
                .ToDictionary(f => f.FolderId);

            if (!folders.TryGetValue(folderId, out var current))
                throw new KeyNotFoundException("Folder not found.");

            var segments = new List<string>();

            var visited = new HashSet<Guid>();

            while (true)
            {
                if (!visited.Add(current.FolderId))
                    throw new InvalidOperationException(
                        "Circular folder hierarchy detected.");

                StorageService.ValidateSegment(current.FolderName);

                segments.Insert(0, current.FolderName);

                if (!current.ParentFolderId.HasValue)
                    break;

                if (!folders.TryGetValue(
                    current.ParentFolderId.Value,
                    out current))
                {
                    throw new InvalidOperationException(
                        "Parent folder hierarchy is invalid.");
                }
            }

            return _storage.GetContentPath(segments.ToArray());
        }

        // GET PARENT FOLDER PATH SEGMENTS
        private string[] GetRelativeFolderSegments(Guid? parentFolderId)
        {
            if (!parentFolderId.HasValue)
                return Array.Empty<string>();

            var folders = _context.Folders
                .AsNoTracking()
                .ToDictionary(f => f.FolderId);

            if (!folders.TryGetValue(
                parentFolderId.Value, out var current))
            {
                throw new KeyNotFoundException(
                    "Parent folder not found.");
            }

            var segments = new List<string>();
            var visited = new HashSet<Guid>();

            while (true)
            {
                if (!visited.Add(current.FolderId))
                    throw new InvalidOperationException(
                        "Circular folder hierarchy detected.");

                StorageService.ValidateSegment(current.FolderName);

                segments.Insert(0, current.FolderName);

                if (!current.ParentFolderId.HasValue)
                    break;

                if (!folders.TryGetValue(
                    current.ParentFolderId.Value,
                    out current))
                {
                    throw new InvalidOperationException(
                        "Parent folder hierarchy is invalid.");
                }
            }

            return segments.ToArray();
        }

        // GET FOLDER DEPTH
        private static int GetFolderDepth(
            FolderModel folder,
            List<FolderModel> allFolders)
        {
            int depth = 0;
            var parentId = folder.ParentFolderId;

            while (parentId.HasValue)
            {
                var parent = allFolders.FirstOrDefault(
                    f => f.FolderId == parentId.Value);

                if (parent == null)
                    break;

                depth++;
                parentId = parent.ParentFolderId;
            }

            return depth;
        }
    }
}
