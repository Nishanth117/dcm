﻿
using FileManagementApi.Data;
using FileManagementApi.Models;

namespace FileManagementApi.Services
{
    public class ActivityLogService
    {
        private readonly FileManagementDbContext _context;

        public ActivityLogService(FileManagementDbContext context)
        {
            _context = context;
        }

        public async Task LogActivityAsync(
            Guid? userId,
            string action,
            string itemType,
            Guid itemId,
            string itemName)
        {
            var activity = new ActivityLogModel
            {
                UserId = userId,
                Action = action,
                ItemType = itemType,
                ItemId = itemId,
                ItemName = itemName,
                ActivityDate = DateTime.UtcNow
            };

            _context.ActivityLogs.Add(activity);

            await _context.SaveChangesAsync();
        }
    }
}
