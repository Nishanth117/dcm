﻿
using FileManagementApi.Models;
using Microsoft.Extensions.Options;

namespace FileManagementApi.Services
{
    public class StorageService
    {
        public string RootPath { get; }
        public string ContentPath { get; }
        public string FoldersMetadataPath { get; }
        public string FilesMetadataPath { get; }

        public StorageService(
            IOptions<StorageSettings> options,
            IWebHostEnvironment environment)
        {
            var settings = options.Value;

            RootPath = Path.GetFullPath(
                Path.Combine(environment.ContentRootPath, settings.RootPath)
            );

            ContentPath = Path.Combine(RootPath, "Content");

            // Kept for compatibility with any existing references.
            FoldersMetadataPath = Path.Combine(RootPath, "folders.json");
            FilesMetadataPath = Path.Combine(RootPath, "files.json");

            Directory.CreateDirectory(ContentPath);

            if (!File.Exists(FoldersMetadataPath))
                File.WriteAllText(FoldersMetadataPath, "[]");

            if (!File.Exists(FilesMetadataPath))
                File.WriteAllText(FilesMetadataPath, "[]");
        }

        // Builds a safe physical path inside the Content folder.
        public string GetContentPath(params string[] segments)
        {
            foreach (string segment in segments)
            {
                ValidateSegment(segment);
            }

            string fullPath = Path.GetFullPath(
                Path.Combine(ContentPath, Path.Combine(segments))
            );

            string relativePath = Path.GetRelativePath(ContentPath, fullPath);

            if (Path.IsPathRooted(relativePath) ||
                relativePath == ".." ||
                relativePath.StartsWith(
                    ".." + Path.DirectorySeparatorChar,
                    StringComparison.Ordinal))
            {
                throw new InvalidOperationException(
                    "The requested path is outside the storage directory.");
            }

            return fullPath;
        }

        // Prevents invalid names and directory traversal.
        public static void ValidateSegment(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name cannot be empty.");

            if (name != name.Trim())
                throw new ArgumentException(
                    "Names cannot start or end with spaces.");

            if (name == "." || name == "..")
                throw new ArgumentException("Invalid name.");

            if (name.EndsWith('.') || name.EndsWith(' '))
                throw new ArgumentException(
                    "Names cannot end with a dot or space.");

            if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||
                name.Contains('/') || name.Contains('\\'))
            {
                throw new ArgumentException(
                    "Name contains invalid characters.");
            }

            string baseName = name.Split('.')[0];

            string[] reservedNames =
            {
                "CON", "PRN", "AUX", "NUL",
                "COM1", "COM2", "COM3", "COM4", "COM5",
                "COM6", "COM7", "COM8", "COM9",
                "LPT1", "LPT2", "LPT3", "LPT4", "LPT5",
                "LPT6", "LPT7", "LPT8", "LPT9"
            };

            if (reservedNames.Contains(
                baseName, StringComparer.OrdinalIgnoreCase))
            {
                throw new ArgumentException(
                    "This name is reserved by Windows.");
            }
        }
    }
}
