﻿
using FileManagementApi.Models;
using Microsoft.Extensions.Options;

namespace FileManagementApi.Services
{
    public class StorageService
    {
        public string RootPath { get; }
        public string ContentPath { get; }
        public string FoldersMetadataPath { get; }
        public string FilesMetadataPath { get; }

        public StorageService(
            IOptions<StorageSettings> options,
            IWebHostEnvironment environment)
        {
            var settings = options.Value;

            RootPath = Path.GetFullPath(
                Path.Combine(
                    environment.ContentRootPath,
                    settings.RootPath
                )
            );

            ContentPath = Path.Combine(RootPath, "Content");

            FoldersMetadataPath =
                Path.Combine(RootPath, "folders.json");

            FilesMetadataPath =
                Path.Combine(RootPath, "files.json");

            Directory.CreateDirectory(ContentPath);

            if (!File.Exists(FoldersMetadataPath))
            {
                File.WriteAllText(FoldersMetadataPath, "[]");
            }

            if (!File.Exists(FilesMetadataPath))
            {
                File.WriteAllText(FilesMetadataPath, "[]");
            }
        }
    }
}
