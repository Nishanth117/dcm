﻿
using Microsoft.EntityFrameworkCore;
using FileManagementApi.Data;
using FileManagementApi.Models;

namespace FileManagementApi.Services
{
    public class PermissionService
    {
        private readonly FileManagementDbContext _context;

        public PermissionService(FileManagementDbContext context)
        {
            _context = context;
        }

        public async Task<bool> HasPermissionAsync(
            Guid userId,
            string role,
            Guid folderId,
            string permission)
        {
            // Admin has full access.
            if (string.Equals(role, "Admin",
                StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            var visitedFolders = new HashSet<Guid>();
            Guid? currentFolderId = folderId;

            // Check the folder and its parent folders.
            // A permission on a parent is inherited by its children.
            while (currentFolderId.HasValue)
            {
                if (!visitedFolders.Add(currentFolderId.Value))
                    return false;

                var folder = await _context.Folders
                    .AsNoTracking()
                    .FirstOrDefaultAsync(f =>
                        f.FolderId == currentFolderId.Value);

                if (folder == null || folder.DeletedAt != null)
                    return false;

                var folderPermission = await _context.FolderPermissions
                    .AsNoTracking()
                    .FirstOrDefaultAsync(p =>
                        p.FolderId == currentFolderId.Value &&
                        p.UserId == userId);

                if (folderPermission != null)
                {
                    // The nearest permission record takes priority.
                    return permission.ToLowerInvariant() switch
                    {
                        "view" => folderPermission.CanView,

                        "download" =>
                            folderPermission.CanView &&
                            folderPermission.CanDownload,

                        "upload" => folderPermission.CanUpload,

                        "edit" => folderPermission.CanEdit,

                        "delete" => folderPermission.CanDelete,

                        _ => false
                    };
                }

                currentFolderId = folder.ParentFolderId;
            }

            // No permission was found.
            return false;
        }
    }
}
