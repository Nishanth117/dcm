﻿
using FileManagementApi.Data;
using FileManagementApi.Models;
using Microsoft.EntityFrameworkCore;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FileManagementApi.Services
{
    public class FileService
    {
        private readonly FileManagementDbContext _context;
        private readonly StorageService _storage;
        private readonly long _maxFileSizeBytes;

        public FileService(
    FileManagementDbContext context,
    StorageService storage,
    IOptions<StorageSettings> options)
        {
            _context = context;
            _storage = storage;

            _maxFileSizeBytes =
                (long)options.Value.MaxFileSizeMB * 1024 * 1024;
        }

        // GET ALL FILES
        public List<FileModel> GetAllFiles()
        {
            return _context.Files
                .AsNoTracking()
                .Where(f => f.DeletedAt == null)
                .OrderBy(f => f.CreatedAt)
                .ToList();
        }

        public List<FileModel> GetDeletedFiles()
        {
            return _context.Files
                .AsNoTracking()
                .Where(f => f.DeletedAt != null)
                .OrderByDescending(f => f.DeletedAt)
                .ToList();
        }


        // CREATE PDF, TXT OR DOCX
        public FileModel CreateFile(
            string fileName,
            string fileType,
            Guid folderId,
            string? content)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                throw new ArgumentException("File name is required.");

            fileName = fileName.Trim();

            if (Path.GetFileName(fileName) != fileName ||
                fileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||
                fileName.IndexOfAny(new[] { '/', '\\' }) >= 0)
            {
                throw new ArgumentException("Invalid file name.");
            }

            // CHECK FOLDER IN DATABASE
            var folder = _context.Folders.FirstOrDefault(f =>
                f.FolderId == folderId &&
                f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException("Folder not found.");

            string extension = fileType.Trim().ToUpperInvariant() switch
            {
                "PDF" => ".pdf",
                "TXT" => ".txt",
                "DOCX" => ".docx",
                _ => throw new ArgumentException(
                    "Only PDF, TXT and DOCX files are supported.")
            };

            string suppliedExtension = Path.GetExtension(fileName);

            if (!string.IsNullOrEmpty(suppliedExtension) &&
                !suppliedExtension.Equals(
                    extension,
                    StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException(
                    "File extension does not match the selected file type.");
            }

            string baseName = Path.GetFileNameWithoutExtension(fileName);

            if (string.IsNullOrWhiteSpace(baseName))
                throw new ArgumentException("Invalid file name.");

            string finalName = baseName + extension;

            // CHECK DUPLICATE FILE NAME
            bool duplicateExists = _context.Files
                .Where(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null)
                .AsEnumerable()
                .Any(f => f.FileName.Equals(
                    finalName,
                    StringComparison.OrdinalIgnoreCase));

            if (duplicateExists)
                throw new InvalidOperationException(
                    "A file with this name already exists in the folder.");

            StorageService.ValidateSegment(finalName);
            string folderPath = GetFolderPhysicalPath(folderId);
            Directory.CreateDirectory(folderPath);
            string storageName = finalName;
            string physicalPath = _storage.GetContentPath(
                GetRelativeFolderSegments(folderId).Append(storageName).ToArray());

            try
            {
                // CREATE ACTUAL FILE
                switch (extension)
                {
                    case ".txt":
                        File.WriteAllText(
                            physicalPath, content ?? "");
                        break;

                    case ".pdf":
                        CreatePdf(
                            physicalPath, content ?? "");
                        break;

                    case ".docx":
                        CreateWord(
                            physicalPath, content ?? "");
                        break;
                }

                // SAVE FILE DETAILS IN SQL SERVER
                var file = new FileModel
                {
                    FileName = finalName,
                    FileType = fileType.Trim().ToUpperInvariant(),
                    FolderId = folderId,
                    StorageName = storageName,
                    FileSize = new FileInfo(physicalPath).Length,
                    CreatedAt = DateTime.UtcNow
                };

                _context.Files.Add(file);
                _context.SaveChanges();

                return file;
            }
            catch
            {
                if (File.Exists(physicalPath))
                    File.Delete(physicalPath);

                throw;
            }
        }

        // GENERATE PDF WITH AUTOMATIC PAGE BREAKS
        private void CreatePdf(string path, string content)
        {
            using (PdfDocument document = new PdfDocument())
            {
                PdfPage page = document.AddPage();

                XGraphics graphics = XGraphics.FromPdfPage(page);

                XFont font = new XFont("Arial", 12);

                double y = 40;
                double lineHeight = 20;
                double maxWidth = page.Width.Point - 80;

                void DrawLine(string line)
                {
                    if (y + lineHeight > page.Height.Point - 40)
                    {
                        graphics.Dispose();

                        page = document.AddPage();

                        graphics = XGraphics.FromPdfPage(page);

                        y = 40;
                    }

                    graphics.DrawString(
                        line,
                        font,
                        XBrushes.Black,
                        new XPoint(40, y));

                    y += lineHeight;
                }

                foreach (string paragraph in
                    content.Replace("\r", "").Split('\n'))
                {
                    string currentLine = "";

                    foreach (string word in paragraph.Split(' '))
                    {
                        string testLine = string.IsNullOrEmpty(currentLine)
                            ? word
                            : currentLine + " " + word;

                        if (graphics.MeasureString(
                                testLine, font).Width > maxWidth
                            && !string.IsNullOrEmpty(currentLine))
                        {
                            DrawLine(currentLine);
                            currentLine = word;
                        }
                        else
                        {
                            currentLine = testLine;
                        }
                    }

                    DrawLine(currentLine);
                    y += 8;
                }

                graphics.Dispose();

                document.Save(path);
            }
        }

        // GENERATE WORD DOCUMENT
        private void CreateWord(string path, string content)
        {
            using (WordprocessingDocument document =
                WordprocessingDocument.Create(
                    path,
                    WordprocessingDocumentType.Document))
            {
                MainDocumentPart mainPart =
                    document.AddMainDocumentPart();

                Body body = new Body();

                foreach (string line in content.Split('\n'))
                {
                    Paragraph paragraph = new Paragraph(
                        new Run(
                            new Text(line)
                            {
                                Space = SpaceProcessingModeValues.Preserve
                            }
                        )
                    );

                    body.Append(paragraph);
                }

                mainPart.Document = new Document(body);

                mainPart.Document.Save();
            }
        }

        // GET FILES BY FOLDER
        public List<FileModel> GetFilesByFolder(Guid folderId)
        {
            return _context.Files
                .AsNoTracking()
                .Where(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null)
                .OrderBy(f => f.CreatedAt)
                .ToList();
        }

        // RENAME FILE (DATABASE AND PHYSICAL FILE)
        public FileModel RenameFile(Guid fileId, string newFileName)
        {
            if (string.IsNullOrWhiteSpace(newFileName))
                throw new ArgumentException("New file name is required.");

            newFileName = newFileName.Trim();
            StorageService.ValidateSegment(newFileName);

            var file = _context.Files.FirstOrDefault(f =>
                f.FileId == fileId && f.DeletedAt == null);
            if (file == null)
                throw new KeyNotFoundException("File not found.");

            string expectedExtension = Path.GetExtension(file.FileName);
            if (!string.Equals(Path.GetExtension(newFileName), expectedExtension,
                StringComparison.OrdinalIgnoreCase))
                throw new ArgumentException(
                    $"The file extension must remain {expectedExtension}.");

            bool duplicateExists = _context.Files
                .Where(f => f.FolderId == file.FolderId &&
                            f.FileId != fileId && f.DeletedAt == null)
                .AsEnumerable()
                .Any(f => f.FileName.Equals(newFileName,
                    StringComparison.OrdinalIgnoreCase));
            if (duplicateExists)
                throw new InvalidOperationException(
                    "A file with this name already exists in the folder.");

            string oldPath = _storage.GetContentPath(
                GetRelativeFolderSegments(file.FolderId).Append(file.StorageName).ToArray());
            string newPath = _storage.GetContentPath(
                GetRelativeFolderSegments(file.FolderId).Append(newFileName).ToArray());

            if (!System.IO.File.Exists(oldPath))
                throw new FileNotFoundException("Physical file was not found.");
            if (System.IO.File.Exists(newPath))
                throw new InvalidOperationException(
                    "A physical file with this name already exists.");

            System.IO.File.Move(oldPath, newPath);
            try
            {
                file.FileName = newFileName;
                file.StorageName = newFileName;
                file.UpdatedAt = DateTime.UtcNow;
                _context.SaveChanges();
                return file;
            }
            catch
            {
                if (System.IO.File.Exists(newPath) &&
                    !System.IO.File.Exists(oldPath))
                    System.IO.File.Move(newPath, oldPath);
                throw;
            }
        }

        // DOWNLOAD FILE
        public (string FilePath, string FileName, string ContentType)
            GetFileForDownload(Guid fileId)
        {
            var file = _context.Files.FirstOrDefault(f =>
                f.FileId == fileId &&
                f.DeletedAt == null);

            if (file == null)
                throw new KeyNotFoundException("File not found.");

            string physicalPath = _storage.GetContentPath(
                GetRelativeFolderSegments(file.FolderId)
                    .Append(file.StorageName).ToArray());

            if (!System.IO.File.Exists(physicalPath))
                throw new FileNotFoundException("Physical file not found.");

            string contentType = file.FileType.ToUpperInvariant() switch
            {
                "PDF" => "application/pdf",
                "TXT" => "text/plain",
                "DOCX" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                _ => "application/octet-stream"
            };

            return (
                physicalPath,
                file.FileName,
                contentType
            );
        }
        // UPLOAD EXISTING FILE
        public async Task<FileModel> UploadFileAsync(
            IFormFile uploadedFile,
            Guid folderId)
        {
            if (uploadedFile == null || uploadedFile.Length == 0)
                throw new ArgumentException("Please select a file.");

            if (uploadedFile.Length > _maxFileSizeBytes)
                throw new ArgumentException(
                    "File size exceeds the maximum allowed size of 50 MB.");

            // Validate folder
            var folder = await _context.Folders.FirstOrDefaultAsync(f =>
                f.FolderId == folderId &&
                f.DeletedAt == null);

            if (folder == null)
                throw new KeyNotFoundException("Folder not found.");

            // Validate filename
            string fileName = Path.GetFileName(uploadedFile.FileName);

            if (string.IsNullOrWhiteSpace(fileName) ||
                fileName != uploadedFile.FileName ||
                fileName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||
                fileName.IndexOfAny(new[] { '/', '\\' }) >= 0)
            {
                throw new ArgumentException("Invalid file name.");
            }

            // Allow only selected file types
            string extension = Path.GetExtension(fileName).ToLowerInvariant();

            string fileType = extension switch
            {
                ".pdf" => "PDF",
                ".txt" => "TXT",
                ".docx" => "DOCX",
                _ => throw new ArgumentException(
                    "Only PDF, TXT and DOCX files are supported.")
            };

            // Check duplicate filename
            bool duplicateExists = await _context.Files
                .Where(f =>
                    f.FolderId == folderId &&
                    f.DeletedAt == null)
                .AnyAsync(f => f.FileName.ToLower() == fileName.ToLower());

            if (duplicateExists)
                throw new InvalidOperationException(
                    "A file with this name already exists in the folder.");

            StorageService.ValidateSegment(fileName);
            string folderPath = GetFolderPhysicalPath(folderId);
            Directory.CreateDirectory(folderPath);
            string storageName = fileName;
            string physicalPath = _storage.GetContentPath(
                GetRelativeFolderSegments(folderId).Append(storageName).ToArray());

            if (System.IO.File.Exists(physicalPath))
                throw new InvalidOperationException(
                    "A physical file with this name already exists.");

            try
            {
                // Save actual file on server
                await using (var stream = new FileStream(
                    physicalPath,
                    FileMode.CreateNew,
                    FileAccess.Write,
                    FileShare.None))
                {
                    await uploadedFile.CopyToAsync(stream);
                }

                // Save metadata in SQL Server
                var file = new FileModel
                {
                    FileName = fileName,
                    FileType = fileType,
                    FolderId = folderId,
                    StorageName = storageName,
                    FileSize = uploadedFile.Length,
                    CreatedAt = DateTime.UtcNow
                };

                _context.Files.Add(file);
                await _context.SaveChangesAsync();

                return file;
            }
            catch
            {
                // Remove physical file if database operation fails
                if (System.IO.File.Exists(physicalPath))
                    System.IO.File.Delete(physicalPath);

                throw;
            }
        }
        // DELETE FILE (SOFT DELETE)
        public FileModel DeleteFile(Guid fileId)
        {
            var file = _context.Files.FirstOrDefault(f =>
                f.FileId == fileId &&
                f.DeletedAt == null);

            if (file == null)
                throw new KeyNotFoundException("File not found.");

            // Mark file as deleted
            file.DeletedAt = DateTime.UtcNow;

            // User ID will be assigned after authentication
            file.DeletedBy = null;

            _context.SaveChanges();

            return file;
        }
        // RESTORE DELETED FILE
        public FileModel RestoreFile(Guid fileId)
        {
            // Find deleted file
            var file = _context.Files.FirstOrDefault(f =>
                f.FileId == fileId &&
                f.DeletedAt != null);

            if (file == null)
                throw new KeyNotFoundException(
                    "Deleted file not found.");

            // Check whether parent folder is active
            bool folderExists = _context.Folders.Any(f =>
                f.FolderId == file.FolderId &&
                f.DeletedAt == null);

            if (!folderExists)
                throw new InvalidOperationException(
                    "Cannot restore file because its parent folder is deleted.");

            // Check duplicate active filename
            bool duplicateExists = _context.Files.Any(f =>
                f.FolderId == file.FolderId &&
                f.FileId != fileId &&
                f.DeletedAt == null &&
                f.FileName == file.FileName);

            if (duplicateExists)
                throw new InvalidOperationException(
                    "Another active file already has this name.");

            // Check whether physical file still exists
            string physicalPath = _storage.GetContentPath(
                GetRelativeFolderSegments(file.FolderId)
                    .Append(file.StorageName).ToArray());

            if (!System.IO.File.Exists(physicalPath))
                throw new FileNotFoundException(
                    "Original physical file was not found.");

            // Restore file
            file.DeletedAt = null;
            file.DeletedBy = null;
            file.UpdatedAt = DateTime.UtcNow;

            _context.SaveChanges();

            return file;
        }
        // SEARCH FILES
        public List<FileModel> SearchFiles(
            string searchTerm,
            string? fileType,
            Guid? folderId)
        {
            if (string.IsNullOrWhiteSpace(searchTerm) &&
                string.IsNullOrWhiteSpace(fileType) &&
                !folderId.HasValue)
            {
                throw new ArgumentException(
                    "Provide a file name, file type, or folder ID.");
            }

            var query = _context.Files
                .AsNoTracking()
                .Where(f => f.DeletedAt == null);

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                searchTerm = searchTerm.Trim();

                query = query.Where(f =>
                    f.FileName.Contains(searchTerm));
            }

            if (!string.IsNullOrWhiteSpace(fileType))
            {
                string normalizedType = fileType.Trim().ToUpperInvariant();

                query = query.Where(f =>
                    f.FileType == normalizedType);
            }

            if (folderId.HasValue)
            {
                query = query.Where(f =>
                    f.FolderId == folderId.Value);
            }

            return query
                .OrderBy(f => f.FileName)
                .ToList();
        }
        public void PermanentlyDeleteFile(Guid fileId)
        {
            var file = _context.Files.FirstOrDefault(f =>
                f.FileId == fileId && f.DeletedAt != null);
            if (file == null)
                throw new KeyNotFoundException(
                    "Deleted file not found in recycle bin.");

            string filePath = _storage.GetContentPath(
                GetRelativeFolderSegments(file.FolderId)
                    .Append(file.StorageName).ToArray());

            if (System.IO.File.Exists(filePath))
                System.IO.File.Delete(filePath);

            _context.Files.Remove(file);
            _context.SaveChanges();
        }

        private string GetFolderPhysicalPath(Guid folderId)
        {
            return _storage.GetContentPath(GetRelativeFolderSegments(folderId));
        }

        private string[] GetRelativeFolderSegments(Guid folderId)
        {
            var folders = _context.Folders
                .AsNoTracking()
                .ToDictionary(f => f.FolderId);

            if (!folders.TryGetValue(folderId, out var current))
                throw new KeyNotFoundException("Folder not found.");

            var segments = new List<string>();
            var visited = new HashSet<Guid>();

            while (true)
            {
                if (!visited.Add(current.FolderId))
                    throw new InvalidOperationException(
                        "Circular folder hierarchy detected.");

                StorageService.ValidateSegment(current.FolderName);
                segments.Insert(0, current.FolderName);

                if (!current.ParentFolderId.HasValue)
                    break;

                if (!folders.TryGetValue(current.ParentFolderId.Value,
                    out current))
                    throw new InvalidOperationException(
                        "Parent folder hierarchy is invalid.");
            }

            return segments.ToArray();
        }

    }
}
