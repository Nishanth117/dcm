
using FileManagementApi.Models;
using FileManagementApi.Services;
using PdfSharp;
using PdfSharp.Fonts;
using Microsoft.EntityFrameworkCore;
using FileManagementApi.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.OpenApi;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<FileManagementDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")
    )
);
PdfSharpLicense.SetAgplLicense();
GlobalFontSettings.UseWindowsFontsUnderWindows = true;
// Add controllers
builder.Services.AddControllers();

// Configure server-side storage
builder.Services.Configure<StorageSettings>(
    builder.Configuration.GetSection("StorageSettings")
);

// Register StorageService
builder.Services.AddSingleton<StorageService>();
builder.Services.AddScoped<FolderService>();
builder.Services.AddScoped<FileService>();
// Configure Swagger
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(options =>
{
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Enter your JWT token."
    });

    options.AddSecurityRequirement(document =>
        new OpenApiSecurityRequirement
        {
            [new OpenApiSecuritySchemeReference("Bearer", document)] = []
        });
});


var jwtKey = builder.Configuration["Jwt:Key"];
Console.WriteLine(
    $"JWT Key Loaded: {!string.IsNullOrWhiteSpace(jwtKey)}"
);

Console.WriteLine(
    $"JWT Key Length: {Encoding.UTF8.GetByteCount(jwtKey ?? "")}"
);

if (string.IsNullOrWhiteSpace(jwtKey) ||
    Encoding.UTF8.GetByteCount(jwtKey) < 32)
{
    throw new InvalidOperationException(
        "JWT signing key must be configured and at least 32 bytes long.");
}

var signingKey = new SymmetricSecurityKey(
    Encoding.UTF8.GetBytes(jwtKey));

builder.Services
    .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters =
            new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = "FileManagementAPI",

                ValidateAudience = true,
                ValidAudience = "FileManagementClient",

                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,

                ClockSkew = TimeSpan.FromMinutes(1)
            };
    });

builder.Services.AddAuthorization();

var app = builder.Build();

// Enable Swagger in Development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Middleware
app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// Start application
app.Run();
